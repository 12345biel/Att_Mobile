package com.example.todolist

data class Todo(
    val task: String,
            var isChecked: Boolean = false
)